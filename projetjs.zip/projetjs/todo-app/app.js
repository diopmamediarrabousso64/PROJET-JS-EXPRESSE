const express = require('express');
const tasks = require('./database');
const app = express();
app.use(express.json());


app.post('/todos', (req, res) => {

});


app.put('/todos/:id', (req, res) => {

});


app.get('/todos', (req, res) => {

});


app.get('/todos/:id', (req, res) => {

});


app.delete('/todos/:id', (req, res) => {

});


app.get('/todos', (req, res) => {

});

app.get('/todos/order', (req, res) => {

});


app.use((req, res) => {
    res.status(404).send('Not Found');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});








const express = require('express');
const bodyParser = require('body-parser');
const tasks = require('./database');

//const app = express();
app.use(bodyParser.json());


app.post('/todos', (req, res) => {
    const newTask = req.body;
    newTask.id = tasks.length + 1;
    newTask.createdAt = new Date();
    tasks.push(newTask);
    res.status(201).json(newTask);
});


app.put('/todos/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    const updatedTask = req.body;
    const index = tasks.findIndex(task => task.id === taskId);
    if (index !== -1) {
        tasks[index] = {...tasks[index], ...updatedTask };
        res.json(tasks[index]);
    } else {
        res.status(404).send('Task not found');
    }
});


app.get('/todos', (req, res) => {
    res.json(tasks.map(({ id, title, priority, createdAt, finished }) => ({ id, title, priority, createdAt, finished })));
});

app.get('/todos/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    const task = tasks.find(task => task.id === taskId);
    if (task) {
        res.json(task);
    } else {
        res.status(404).send('Task not found');
    }
});


app.delete('/todos/:id', (req, res) => {
    const taskId = parseInt(req.params.id);
    const index = tasks.findIndex(task => task.id === taskId);
    if (index !== -1) {
        tasks.splice(index, 1);
        res.sendStatus(204);
    } else {
        res.status(404).send('Task not found');
    }
});


app.get('/todos', (req, res) => {
    const { search } = req.query;
    if (search) {
        const filteredTasks = tasks.filter(task => task.title.toLowerCase().includes(search.toLowerCase()));
        res.json(filteredTasks);
    } else {
        res.json(tasks);
    }
});


app.get('/todos/order', (req, res) => {
    const sortedTasks = [...tasks].sort((a, b) => a.priority - b.priority);
    res.json(sortedTasks);
});


app.use((req, res) => {
    res.status(404).send('Not Found');
});

//const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});