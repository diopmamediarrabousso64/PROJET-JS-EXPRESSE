// database.js
let tasks = [
    { id: 1, title: "Réviser pour l'examen", description: "aprendre mes lecons", createdAt: new Date(), finished: false, priority: 2 },
    { id: 2, title: "Rendre un devoir", description: "finir et soumettre au prof", createdAt: new Date(), finished: false, priority: 1 },
    { id: 3, title: "Faire la cuisine", description: "aller au marcher et preparer", createdAt: new Date(), finished: false, priority: 3 },
    { id: 4, title: "faire la menage", description: "balayer", createdAt: new Date(), finished: false, priority: 2 },
    { id: 5, title: "faire la linge", description: "mettre les habits dns le machine a laver", createdAt: new Date(), finished: false, priority: 1 }
];

module.exports = tasks;